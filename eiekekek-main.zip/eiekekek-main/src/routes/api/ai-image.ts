import "@tanstack/react-start";
import { createFileRoute } from "@tanstack/react-router";

const GATEWAY = "https://ai.gateway.lovable.dev/v1/chat/completions";
const MODEL = "google/gemini-2.5-flash-image";

type Body = {
  op: "generate" | "edit";
  prompt: string;
  image?: string; // dataURL
};

async function callGateway(messages: unknown[], key: string) {
  const r = await fetch(GATEWAY, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ model: MODEL, messages, modalities: ["image", "text"] }),
  });
  if (!r.ok) {
    const txt = await r.text();
    throw new Response(`AI gateway error ${r.status}: ${txt}`, { status: r.status });
  }
  const data = (await r.json()) as {
    choices: { message: { images?: { image_url: { url: string } }[]; content?: string } }[];
  };
  const img = data.choices?.[0]?.message?.images?.[0]?.image_url?.url;
  if (!img) throw new Response("No image returned", { status: 502 });
  return img; // data:image/png;base64,...
}

export const Route = createFileRoute("/api/ai-image")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        let body: Body;
        try {
          body = (await request.json()) as Body;
        } catch {
          return new Response("Invalid JSON", { status: 400 });
        }

        if (!body?.prompt || typeof body.prompt !== "string" || body.prompt.length > 2000) {
          return new Response("Invalid prompt", { status: 400 });
        }

        try {
          let url: string;
          if (body.op === "edit") {
            if (!body.image || !body.image.startsWith("data:image/")) {
              return new Response("Invalid image", { status: 400 });
            }
            url = await callGateway(
              [
                {
                  role: "user",
                  content: [
                    { type: "text", text: body.prompt },
                    { type: "image_url", image_url: { url: body.image } },
                  ],
                },
              ],
              key,
            );
          } else {
            url = await callGateway(
              [{ role: "user", content: body.prompt }],
              key,
            );
          }
          return Response.json({ url });
        } catch (e) {
          if (e instanceof Response) return e;
          return new Response(String(e), { status: 500 });
        }
      },
    },
  },
});
