import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, useCallback, useMemo } from "react";
import {
  Palette,
  BookOpen,
  Plus,
  List,
  ImageIcon,
  Trash2,
  Pencil,
  ArrowLeft,
  Save,
  Eraser,
  Undo2,
  Brush,
  Settings as SettingsIcon,
  Upload,
  X,
  Download,
  Share2,
  Lock,
  Link as LinkIcon,
  Copy,
  Check,
  Sparkles,
  Wand2,
  Layout,
  Type as TypeIcon,
  Smile,
  Bookmark,
  Loader2,
} from "lucide-react";

const ICON_KEY = "comic-maker-studio:appIcon";
const BRAND_KEY = "comic-maker-studio:brandKit";

export const Route = createFileRoute("/")({
  component: Index,
});

export type Sticker = {
  id: string;
  emoji: string;
  x: number; // 0..1
  y: number; // 0..1
  size: number; // 0.05..0.4 of panel
};

export type TextStyleId = "classic" | "bold" | "shadow" | "gradient" | "outline";

export type Panel = {
  id: string;
  caption: string;
  dialogue: string;
  bg: string;
  drawing: string; // dataURL of canvas
  imageUrl?: string; // uploaded or AI-generated background image (dataURL)
  imageFilter?: string; // CSS filter string
  stickers?: Sticker[];
  textStyle?: TextStyleId;
  font?: string;
};

export type Comic = {
  id: string;
  title: string;
  description: string;
  createdAt: number;
  panels: Panel[];
};

type BrandKit = {
  palette: string[];
  fonts: string[];
  logos: string[];
};

const STORAGE_KEY = "comic-maker-studio:comics";

const BG_COLORS = [
  "#FFF7ED", "#FEF3C7", "#DBEAFE", "#FCE7F3",
  "#DCFCE7", "#EDE9FE", "#FFE4E6", "#CFFAFE",
];

// iOS system colors (light + dark variants) — Apple Human Interface Guidelines
const PALETTE = [
  "#000000", "#8E8E93", "#AEAEB2", "#C7C7CC", "#D1D1D6", "#FFFFFF",
  "#FF3B30", "#FF9500", "#FFCC00", "#34C759", "#00C7BE", "#30B0C7",
  "#007AFF", "#5856D6", "#AF52DE", "#FF2D55", "#A2845E", "#8B4513",
  "#FF6482", "#FFD60A", "#32D74B", "#64D2FF", "#5E5CE6", "#BF5AF2",
];

const BRUSHES: { id: string; label: string; size: number }[] = [
  { id: "fine", label: "Fine", size: 2 },
  { id: "medium", label: "Medium", size: 6 },
  { id: "bold", label: "Bold", size: 14 },
  { id: "marker", label: "Marker", size: 26 },
];

const STICKER_EMOJIS = [
  "💥", "💢", "✨", "⭐", "❤️", "💔", "💭", "💬", "❓", "❗",
  "🔥", "⚡", "💀", "👀", "👊", "🙌", "🎉", "🌟", "☁️", "🌈",
  "😀", "😂", "😍", "😎", "😭", "😱", "🤔", "🤯", "🥳", "😴",
  "🐶", "🐱", "🦄", "🍕", "🍔", "☕", "🎵", "📱", "💻", "🚀",
];

const FONTS = [
  { id: "system", label: "System", css: "-apple-system, system-ui, sans-serif" },
  { id: "comic", label: "Comic", css: "'Comic Sans MS', 'Chalkboard SE', cursive" },
  { id: "serif", label: "Serif", css: "Georgia, 'Times New Roman', serif" },
  { id: "mono", label: "Mono", css: "'SF Mono', Menlo, monospace" },
  { id: "impact", label: "Impact", css: "Impact, 'Arial Black', sans-serif" },
];

const TEXT_STYLES: { id: TextStyleId; label: string; bubble: string; text: string }[] = [
  { id: "classic", label: "Classic", bubble: "bg-white border-2 border-slate-900 text-slate-900", text: "" },
  { id: "bold", label: "Bold", bubble: "bg-slate-900 text-white border-2 border-slate-900", text: "font-bold" },
  { id: "shadow", label: "Shadow", bubble: "bg-white border-2 border-slate-900 text-slate-900 shadow-[4px_4px_0_0_#0f172a]", text: "" },
  { id: "gradient", label: "Gradient", bubble: "bg-gradient-to-r from-fuchsia-500 to-indigo-500 text-white border-2 border-slate-900", text: "font-semibold" },
  { id: "outline", label: "Outline", bubble: "bg-transparent border-2 border-slate-900 text-slate-900", text: "font-bold tracking-wide" },
];

const PHOTO_FILTERS = [
  { id: "none", label: "None", css: "none" },
  { id: "bw", label: "B&W", css: "grayscale(1) contrast(1.1)" },
  { id: "vintage", label: "Vintage", css: "sepia(0.6) contrast(1.1) saturate(1.2)" },
  { id: "comic", label: "Comic", css: "contrast(1.6) saturate(1.8) brightness(1.05)" },
  { id: "cool", label: "Cool", css: "hue-rotate(-15deg) saturate(1.3)" },
  { id: "warm", label: "Warm", css: "hue-rotate(15deg) saturate(1.2) brightness(1.05)" },
  { id: "noir", label: "Noir", css: "grayscale(1) contrast(1.5) brightness(0.85)" },
  { id: "dream", label: "Dream", css: "blur(0.5px) saturate(1.3) brightness(1.1)" },
];

const EXPORT_FORMATS = [
  { id: "square", label: "Square (1080×1080)", w: 1080, h: 1080, single: true },
  { id: "story", label: "IG Story (1080×1920)", w: 1080, h: 1920, single: true },
  { id: "post", label: "IG Post (1080×1350)", w: 1080, h: 1350, single: false },
  { id: "twitter", label: "Twitter Card (1200×675)", w: 1200, h: 675, single: false },
  { id: "a4", label: "A4 Print (2480×3508)", w: 2480, h: 3508, single: false },
  { id: "wide", label: "Wide Strip (2400×800)", w: 2400, h: 800, single: false },
];

const TEMPLATES: { id: string; label: string; emoji: string; panels: Partial<Panel>[] }[] = [
  {
    id: "blank",
    label: "Blank",
    emoji: "📄",
    panels: [],
  },
  {
    id: "fourpanel",
    label: "4-Panel Strip",
    emoji: "📰",
    panels: [
      { caption: "Setup", bg: BG_COLORS[0] },
      { caption: "Build-up", bg: BG_COLORS[2] },
      { caption: "Twist", bg: BG_COLORS[5] },
      { caption: "Punchline", bg: BG_COLORS[3] },
    ],
  },
  {
    id: "hero",
    label: "Hero Origin",
    emoji: "🦸",
    panels: [
      { caption: "An ordinary day...", bg: BG_COLORS[2], dialogue: "Just another Monday." },
      { caption: "Until...", bg: BG_COLORS[5], dialogue: "What was that?!" },
      { caption: "Powers awaken!", bg: BG_COLORS[6], dialogue: "I can... fly?" },
      { caption: "The hero is born.", bg: BG_COLORS[0] },
    ],
  },
  {
    id: "meme",
    label: "Meme Template",
    emoji: "😂",
    panels: [
      { caption: "Me trying to focus", bg: BG_COLORS[1] },
      { caption: "My brain at 3am", bg: BG_COLORS[3], dialogue: "Remember that thing from 2014?" },
    ],
  },
  {
    id: "love",
    label: "Mini Romance",
    emoji: "💕",
    panels: [
      { caption: "First meet", bg: BG_COLORS[3], dialogue: "Hi..." },
      { caption: "Coffee date", bg: BG_COLORS[1], dialogue: "Tell me everything." },
      { caption: "The end?", bg: BG_COLORS[7], dialogue: "To be continued..." },
    ],
  },
];

function loadBrandKit(): BrandKit {
  try {
    const raw = localStorage.getItem(BRAND_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    /* ignore */
  }
  return { palette: [], fonts: [], logos: [] };
}

function saveBrandKit(kit: BrandKit) {
  try {
    localStorage.setItem(BRAND_KEY, JSON.stringify(kit));
  } catch {
    /* ignore */
  }
}

function loadComics(): Comic[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function saveComics(comics: Comic[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(comics));
}

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function Index() {
  const [comics, setComics] = useState<Comic[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [appIcon, setAppIcon] = useState<string>("");

  useEffect(() => {
    setComics(loadComics());
    try {
      setAppIcon(localStorage.getItem(ICON_KEY) || "");
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (appIcon) {
      const link =
        (document.querySelector("link[rel='icon']") as HTMLLinkElement) ||
        Object.assign(document.createElement("link"), { rel: "icon" });
      link.href = appIcon;
      if (!link.isConnected) document.head.appendChild(link);
    }
  }, [appIcon]);

  const persist = (next: Comic[]) => {
    setComics(next);
    saveComics(next);
  };

  const saveIcon = (dataUrl: string) => {
    setAppIcon(dataUrl);
    try {
      if (dataUrl) localStorage.setItem(ICON_KEY, dataUrl);
      else localStorage.removeItem(ICON_KEY);
    } catch {
      /* ignore */
    }
  };

  const createComic = (
    title: string,
    description: string,
    templateId: string,
  ) => {
    const template = TEMPLATES.find((t) => t.id === templateId) ?? TEMPLATES[0];
    const c: Comic = {
      id: uid(),
      title: title || "Untitled Comic",
      description,
      createdAt: Date.now(),
      panels: template.panels.map((p, i) => ({
        id: uid(),
        caption: p.caption ?? "",
        dialogue: p.dialogue ?? "",
        bg: p.bg ?? BG_COLORS[i % BG_COLORS.length],
        drawing: "",
      })),
    };
    persist([c, ...comics]);
    setShowCreate(false);
    setEditingId(c.id);
  };

  const deleteComic = (id: string) => {
    persist(comics.filter((c) => c.id !== id));
  };

  const updateComic = (updated: Comic) => {
    persist(comics.map((c) => (c.id === updated.id ? updated : c)));
  };

  const editing = comics.find((c) => c.id === editingId) || null;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      <header className="sticky top-0 z-30 backdrop-blur bg-white/80 border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            {appIcon ? (
              <img
                src={appIcon}
                alt="App icon"
                className="w-9 h-9 rounded-xl object-cover shadow-sm border border-slate-200"
              />
            ) : (
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 via-fuchsia-500 to-rose-500 flex items-center justify-center shadow-sm">
                <Palette className="w-5 h-5 text-white" />
              </div>
            )}
            <div className="leading-tight">
              <p className="text-[15px] font-semibold tracking-tight">
                Comic Maker Studio
              </p>
              <p className="text-[11px] text-slate-500">
                Draw, write, publish your panels
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowSettings(true)}
              className="inline-flex items-center justify-center w-9 h-9 rounded-lg text-slate-600 hover:bg-slate-100 transition"
              aria-label="Settings"
            >
              <SettingsIcon className="w-4 h-4" />
            </button>
            {!editing && (
              <button
                onClick={() => setShowCreate(true)}
                className="hidden sm:inline-flex items-center gap-1.5 text-sm font-medium px-3.5 py-2 rounded-lg bg-slate-900 text-white hover:bg-slate-800 transition"
              >
                <Plus className="w-4 h-4" /> New comic
              </button>
            )}
          </div>
        </div>
      </header>


      <main className="max-w-6xl mx-auto px-4 md:px-6 py-8 md:py-12">
        {editing ? (
          <ComicEditor
            comic={editing}
            onBack={() => setEditingId(null)}
            onChange={updateComic}
          />
        ) : (
          <>
            <section className="mb-8 md:mb-10">
              <span className="inline-flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full">
                <BookOpen className="w-3 h-3" /> Studio
              </span>
              <h1 className="mt-3 text-3xl md:text-5xl font-semibold tracking-tight text-slate-900">
                Create your{" "}
                <span className="bg-gradient-to-r from-indigo-500 via-fuchsia-500 to-rose-500 bg-clip-text text-transparent">
                  comics
                </span>
                .
              </h1>
              <p className="mt-3 text-slate-500 max-w-xl">
                Sketch panels with the brush studio, drop in dialogue and
                captions, and stitch it all into a story.
              </p>

              <button
                onClick={() => setShowCreate(true)}
                className="mt-6 inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-900 text-white font-medium shadow-sm hover:bg-slate-800 transition"
              >
                <Plus className="w-4 h-4" /> Create new comic
              </button>
            </section>

            <section>
              <div className="flex items-center justify-between mb-3">
                <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-700 uppercase tracking-wider">
                  <List className="w-4 h-4" /> Your comics
                </h2>
                <span className="text-xs text-slate-400">
                  {comics.length} total
                </span>
              </div>

              {comics.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-slate-300 bg-white py-16 flex flex-col items-center text-slate-400">
                  <ImageIcon className="w-10 h-10 mb-3" />
                  <p className="font-medium text-slate-600">No comics yet</p>
                  <p className="text-sm">Create your first comic to get started</p>
                </div>
              ) : (
                <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {comics.map((c) => (
                    <li
                      key={c.id}
                      className="group rounded-2xl border border-slate-200 bg-white p-4 hover:shadow-md hover:border-slate-300 transition cursor-pointer"
                      onClick={() => setEditingId(c.id)}
                    >
                      <div className="aspect-[4/3] rounded-xl overflow-hidden border border-slate-100 bg-slate-50 mb-3 grid grid-cols-2 grid-rows-2 gap-0.5">
                        {[0, 1, 2, 3].map((i) => {
                          const p = c.panels[i];
                          return (
                            <div
                              key={i}
                              className="bg-white flex items-center justify-center"
                              style={{ background: p?.bg ?? "#F8FAFC" }}
                            >
                              {p?.drawing ? (
                                <img
                                  src={p.drawing}
                                  alt=""
                                  className="w-full h-full object-cover"
                                />
                              ) : null}
                            </div>
                          );
                        })}
                      </div>
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="font-medium text-slate-900 truncate">
                            {c.title}
                          </p>
                          <p className="text-xs text-slate-500 truncate">
                            {c.panels.length} panel
                            {c.panels.length === 1 ? "" : "s"}
                            {c.description ? ` • ${c.description}` : ""}
                          </p>
                        </div>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditingId(c.id);
                            }}
                            className="p-1.5 rounded-md hover:bg-slate-100 text-slate-600"
                            aria-label="Edit"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm(`Delete "${c.title}"?`))
                                deleteComic(c.id);
                            }}
                            className="p-1.5 rounded-md hover:bg-red-50 text-red-500"
                            aria-label="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </main>

      {showCreate && (
        <CreateModal
          onClose={() => setShowCreate(false)}
          onCreate={createComic}
        />
      )}

      {showSettings && (
        <SettingsModal
          icon={appIcon}
          onClose={() => setShowSettings(false)}
          onSave={saveIcon}
        />
      )}
    </div>
  );
}

function SettingsModal({
  icon,
  onClose,
  onSave,
}: {
  icon: string;
  onClose: () => void;
  onSave: (dataUrl: string) => void;
}) {
  const [preview, setPreview] = useState(icon);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const processFile = (file: File) => {
    setError("");
    if (!file.type.startsWith("image/")) {
      setError("Please choose an image file.");
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setError("Image must be under 2 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      // Re-encode to a square 256x256 PNG for a crisp icon
      const img = new Image();
      img.onload = () => {
        const size = 256;
        const canvas = document.createElement("canvas");
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext("2d")!;
        const scale = Math.max(size / img.width, size / img.height);
        const w = img.width * scale;
        const h = img.height * scale;
        ctx.drawImage(img, (size - w) / 2, (size - h) / 2, w, h);
        setPreview(canvas.toDataURL("image/png"));
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  };

  return (
    <div
      className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 border border-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-1">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-indigo-500" /> Settings
          </h3>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-500 hover:bg-slate-100"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <p className="text-sm text-slate-500 mb-5">
          Personalize the look of your studio.
        </p>

        <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
          App icon
        </label>

        <div className="flex items-center gap-4 mb-3">
          <div className="w-20 h-20 rounded-2xl bg-slate-100 border border-slate-200 overflow-hidden flex items-center justify-center shrink-0">
            {preview ? (
              <img
                src={preview}
                alt="Icon preview"
                className="w-full h-full object-cover"
              />
            ) : (
              <Palette className="w-7 h-7 text-slate-400" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slate-800">
              Upload an image
            </p>
            <p className="text-xs text-slate-500 mb-2">
              Square works best. PNG or JPG, up to 2 MB.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => fileRef.current?.click()}
                className="inline-flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-slate-800"
              >
                <Upload className="w-3.5 h-3.5" /> Choose
              </button>
              {preview && (
                <button
                  onClick={() => setPreview("")}
                  className="inline-flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:border-red-300 hover:text-red-600"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Remove
                </button>
              )}
            </div>
          </div>
        </div>

        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) processFile(f);
            e.target.value = "";
          }}
        />

        {error && (
          <p className="text-sm text-red-600 mb-3">{error}</p>
        )}

        <div className="flex justify-end gap-2 mt-6">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-sm text-slate-600 hover:bg-slate-100"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onSave(preview);
              onClose();
            }}
            className="px-4 py-2 rounded-lg text-sm bg-slate-900 text-white font-medium hover:bg-slate-800"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

function CreateModal({
  onClose,
  onCreate,
}: {
  onClose: () => void;
  onCreate: (title: string, description: string, templateId: string) => void;
}) {
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [templateId, setTemplateId] = useState<string>("blank");
  return (
    <div
      className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-6 border border-slate-200 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-lg font-semibold mb-1 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-indigo-500" /> New comic
        </h3>
        <p className="text-sm text-slate-500 mb-5">
          Give your story a name and pick a starting template.
        </p>
        <label className="block text-xs font-medium text-slate-600 mb-1.5 uppercase tracking-wide">
          Title
        </label>
        <input
          autoFocus
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="My awesome comic"
          className="w-full border border-slate-300 rounded-lg px-3 py-2 mb-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
        />
        <label className="block text-xs font-medium text-slate-600 mb-1.5 uppercase tracking-wide">
          Description
        </label>
        <textarea
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
          placeholder="What's it about?"
          rows={2}
          className="w-full border border-slate-300 rounded-lg px-3 py-2 mb-5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
        />
        <label className="block text-xs font-medium text-slate-600 mb-1.5 uppercase tracking-wide flex items-center gap-1.5">
          <Layout className="w-3.5 h-3.5" /> Template
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-5">
          {TEMPLATES.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTemplateId(t.id)}
              className={`flex flex-col items-start gap-1 p-3 rounded-xl border-2 text-left transition ${
                templateId === t.id
                  ? "border-indigo-500 bg-indigo-50"
                  : "border-slate-200 hover:border-slate-300"
              }`}
            >
              <span className="text-xl">{t.emoji}</span>
              <span className="text-xs font-medium text-slate-900">{t.label}</span>
              <span className="text-[10px] text-slate-500">
                {t.panels.length === 0 ? "Start empty" : `${t.panels.length} panels`}
              </span>
            </button>
          ))}
        </div>
        <div className="flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-sm text-slate-600 hover:bg-slate-100"
          >
            Cancel
          </button>
          <button
            onClick={() => onCreate(title.trim(), desc.trim(), templateId)}
            className="px-4 py-2 rounded-lg text-sm bg-slate-900 text-white font-medium hover:bg-slate-800"
          >
            Create
          </button>
        </div>
      </div>
    </div>
  );
}

function renderTextStyleToCanvas(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  w: number,
  h: number,
  style: TextStyleId,
  fontCss: string,
  fontSize: number,
) {
  ctx.save();
  switch (style) {
    case "bold":
      ctx.fillStyle = "#0F172A";
      ctx.strokeStyle = "#0F172A";
      ctx.lineWidth = 4;
      ctx.fillRect(x, y, w, h);
      ctx.strokeRect(x, y, w, h);
      ctx.fillStyle = "#ffffff";
      ctx.font = `700 ${fontSize}px ${fontCss}`;
      break;
    case "shadow":
      ctx.fillStyle = "#0F172A";
      ctx.fillRect(x + 8, y + 8, w, h);
      ctx.fillStyle = "#ffffff";
      ctx.strokeStyle = "#0F172A";
      ctx.lineWidth = 4;
      ctx.fillRect(x, y, w, h);
      ctx.strokeRect(x, y, w, h);
      ctx.fillStyle = "#0F172A";
      ctx.font = `600 ${fontSize}px ${fontCss}`;
      break;
    case "gradient": {
      const grad = ctx.createLinearGradient(x, y, x + w, y);
      grad.addColorStop(0, "#d946ef");
      grad.addColorStop(1, "#6366f1");
      ctx.fillStyle = grad;
      ctx.strokeStyle = "#0F172A";
      ctx.lineWidth = 4;
      ctx.fillRect(x, y, w, h);
      ctx.strokeRect(x, y, w, h);
      ctx.fillStyle = "#ffffff";
      ctx.font = `700 ${fontSize}px ${fontCss}`;
      break;
    }
    case "outline":
      ctx.strokeStyle = "#0F172A";
      ctx.lineWidth = 4;
      ctx.strokeRect(x, y, w, h);
      ctx.fillStyle = "#0F172A";
      ctx.font = `700 ${fontSize}px ${fontCss}`;
      break;
    case "classic":
    default:
      ctx.fillStyle = "#ffffff";
      ctx.strokeStyle = "#0F172A";
      ctx.lineWidth = 4;
      ctx.fillRect(x, y, w, h);
      ctx.strokeRect(x, y, w, h);
      ctx.fillStyle = "#0F172A";
      ctx.font = `600 ${fontSize}px ${fontCss}`;
      break;
  }
  ctx.textBaseline = "middle";
  const padX = 16;
  // basic word wrap into one or two lines
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const w0 of words) {
    const test = line ? line + " " + w0 : w0;
    if (ctx.measureText(test).width > w - padX * 2 && line) {
      lines.push(line);
      line = w0;
      if (lines.length >= 1) break;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);
  const lh = fontSize * 1.1;
  const startY = y + h / 2 - ((lines.length - 1) * lh) / 2;
  for (let i = 0; i < Math.min(lines.length, 2); i++) {
    ctx.fillText(lines[i], x + padX, startY + i * lh);
  }
  ctx.restore();
}

async function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

async function renderPanelToCanvas(
  ctx: CanvasRenderingContext2D,
  panel: Panel,
  x: number,
  y: number,
  size: number,
) {
  ctx.save();
  // bg
  ctx.fillStyle = panel.bg;
  ctx.fillRect(x, y, size, size);
  // image
  if (panel.imageUrl) {
    try {
      const img = await loadImage(panel.imageUrl);
      ctx.save();
      // apply CSS-like filter where supported
      const f = PHOTO_FILTERS.find((p) => p.id === (panel.imageFilter ?? "none"));
      if (f && f.css !== "none") {
        // canvas filter accepts CSS filter strings
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        ctx.filter = f.css;
      }
      // cover-fit
      const r = Math.max(size / img.width, size / img.height);
      const dw = img.width * r;
      const dh = img.height * r;
      ctx.drawImage(img, x + (size - dw) / 2, y + (size - dh) / 2, dw, dh);
      ctx.restore();
    } catch {
      /* ignore */
    }
  }
  // drawing
  if (panel.drawing) {
    try {
      const img = await loadImage(panel.drawing);
      ctx.drawImage(img, x, y, size, size);
    } catch {
      /* ignore */
    }
  }
  // stickers
  for (const s of panel.stickers ?? []) {
    const ss = s.size * size;
    ctx.save();
    ctx.font = `${ss}px -apple-system, system-ui, sans-serif`;
    ctx.textBaseline = "middle";
    ctx.textAlign = "center";
    ctx.fillText(s.emoji, x + s.x * size, y + s.y * size);
    ctx.restore();
  }
  // text
  const fontCss =
    FONTS.find((f) => f.id === panel.font)?.css ?? FONTS[0].css;
  const style: TextStyleId = panel.textStyle ?? "classic";
  if (panel.dialogue) {
    const tw = Math.min(size * 0.6, size - 40);
    const th = Math.max(60, size * 0.1);
    renderTextStyleToCanvas(
      ctx,
      panel.dialogue,
      x + size - tw - 20,
      y + 20,
      tw,
      th,
      style,
      fontCss,
      Math.round(size * 0.04),
    );
  }
  if (panel.caption) {
    renderTextStyleToCanvas(
      ctx,
      panel.caption,
      x + 20,
      y + size - 70,
      size - 40,
      50,
      style,
      fontCss,
      Math.round(size * 0.035),
    );
  }
  ctx.restore();
}

function ComicEditor({
  comic,
  onBack,
  onChange,
}: {
  comic: Comic;
  onBack: () => void;
  onChange: (c: Comic) => void;
}) {
  const [activePanelId, setActivePanelId] = useState<string | null>(
    comic.panels[0]?.id ?? null,
  );
  const [showShare, setShowShare] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [showBrand, setShowBrand] = useState(false);
  const [brand, setBrand] = useState<BrandKit>({ palette: [], fonts: [], logos: [] });

  useEffect(() => {
    setBrand(loadBrandKit());
  }, []);

  const addPanel = () => {
    const panel: Panel = {
      id: uid(),
      caption: "",
      dialogue: "",
      bg: BG_COLORS[comic.panels.length % BG_COLORS.length],
      drawing: "",
    };
    onChange({ ...comic, panels: [...comic.panels, panel] });
    setActivePanelId(panel.id);
  };

  const updatePanel = (id: string, patch: Partial<Panel>) => {
    onChange({
      ...comic,
      panels: comic.panels.map((p) => (p.id === id ? { ...p, ...patch } : p)),
    });
  };

  const removePanel = (id: string) => {
    onChange({ ...comic, panels: comic.panels.filter((p) => p.id !== id) });
    if (activePanelId === id) setActivePanelId(null);
  };

  const active = comic.panels.find((p) => p.id === activePanelId) ?? null;

  const exportPNG = async (formatId: string) => {
    if (comic.panels.length === 0) return;
    const fmt = EXPORT_FORMATS.find((f) => f.id === formatId) ?? EXPORT_FORMATS[0];
    const W = fmt.w;
    const H = fmt.h;
    const c = document.createElement("canvas");
    c.width = W;
    c.height = H;
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, W, H);

    const padding = Math.round(Math.min(W, H) * 0.025);
    const titleH = Math.round(H * 0.06);
    const titleSize = Math.round(titleH * 0.6);
    ctx.fillStyle = "#0F172A";
    ctx.font = `700 ${titleSize}px -apple-system, system-ui, sans-serif`;
    ctx.textBaseline = "middle";
    ctx.fillText(comic.title || "Untitled", padding, padding + titleH / 2);

    const panelCount = comic.panels.length;
    const cols = Math.max(
      1,
      Math.round(Math.sqrt(panelCount * (W / (H - titleH)))),
    );
    const rows = Math.ceil(panelCount / cols);
    const availH = H - titleH - padding * (rows + 1);
    const availW = W - padding * (cols + 1);
    const tile = Math.floor(Math.min(availW / cols, availH / rows));
    const gridW = tile * cols + padding * (cols - 1);
    const gridH = tile * rows + padding * (rows - 1);
    const offsetX = Math.floor((W - gridW) / 2);
    const offsetY = titleH + padding + Math.floor((availH - gridH) / 2);

    for (let i = 0; i < comic.panels.length; i++) {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const x = offsetX + col * (tile + padding);
      const y = offsetY + row * (tile + padding);
      // eslint-disable-next-line no-await-in-loop
      await renderPanelToCanvas(ctx, comic.panels[i], x, y, tile);
      ctx.strokeStyle = "#0F172A";
      ctx.lineWidth = 4;
      ctx.strokeRect(x, y, tile, tile);
    }

    const url = c.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(comic.title || "comic").replace(/[^a-z0-9-_]+/gi, "-")}-${fmt.id}.png`;
    a.click();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-2">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm text-slate-600 hover:text-slate-900"
        >
          <ArrowLeft className="w-4 h-4" /> Back to library
        </button>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setShowBrand(true)}
            className="inline-flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100"
          >
            <Bookmark className="w-3.5 h-3.5" /> Brand kit
          </button>
          <button
            onClick={() => setShowShare(true)}
            className="inline-flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100"
          >
            <Share2 className="w-3.5 h-3.5" /> Share
          </button>
          <button
            onClick={() => setShowExport(true)}
            disabled={comic.panels.length === 0}
            className="inline-flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Wand2 className="w-3.5 h-3.5" /> Magic Export
          </button>
          <span className="hidden md:flex items-center gap-1.5 text-xs text-emerald-600 bg-emerald-50 border border-emerald-100 px-2.5 py-1 rounded-full">
            <Save className="w-3.5 h-3.5" /> Auto-saved
          </span>
        </div>
      </div>

      {showShare && (
        <ShareDialog comic={comic} onClose={() => setShowShare(false)} />
      )}
      {showExport && (
        <ExportDialog
          onClose={() => setShowExport(false)}
          onExport={(id) => {
            void exportPNG(id);
            setShowExport(false);
          }}
        />
      )}
      {showBrand && (
        <BrandKitDialog
          kit={brand}
          onClose={() => setShowBrand(false)}
          onSave={(k) => {
            setBrand(k);
            saveBrandKit(k);
          }}
        />
      )}

      <input
        value={comic.title}
        onChange={(e) => onChange({ ...comic, title: e.target.value })}
        className="text-3xl md:text-4xl font-semibold tracking-tight w-full bg-transparent outline-none border-b border-transparent focus:border-slate-300 mb-2"
      />
      <input
        value={comic.description}
        onChange={(e) => onChange({ ...comic, description: e.target.value })}
        placeholder="Add a description..."
        className="text-slate-500 w-full bg-transparent outline-none mb-8"
      />

      {active && (
        <div className="mb-8">
          <PanelStudio
            key={active.id}
            panel={active}
            brand={brand}
            onChange={(patch) => updatePanel(active.id, patch)}
          />
        </div>
      )}

      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-slate-700 uppercase tracking-wider">
          Panels
        </h3>
        <button
          onClick={addPanel}
          className="inline-flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-slate-800"
        >
          <Plus className="w-4 h-4" /> Add panel
        </button>
      </div>

      {comic.panels.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white py-16 flex flex-col items-center text-slate-400">
          <ImageIcon className="w-10 h-10 mb-3" />
          <p className="font-medium text-slate-600">No panels yet</p>
          <p className="text-sm">Add your first panel above</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {comic.panels.map((p, i) => (
            <button
              key={p.id}
              onClick={() => setActivePanelId(p.id)}
              className={`group relative aspect-square rounded-xl overflow-hidden border-2 transition ${
                activePanelId === p.id
                  ? "border-indigo-500 shadow-md"
                  : "border-slate-200 hover:border-slate-400"
              }`}
              style={{ background: p.bg }}
            >
              {p.imageUrl && (
                <img
                  src={p.imageUrl}
                  alt=""
                  className="absolute inset-0 w-full h-full object-cover"
                  style={{
                    filter:
                      PHOTO_FILTERS.find((f) => f.id === (p.imageFilter ?? "none"))?.css ?? "none",
                  }}
                />
              )}
              {p.drawing && (
                <img
                  src={p.drawing}
                  alt=""
                  className="absolute inset-0 w-full h-full object-cover"
                />
              )}
              {(p.stickers ?? []).map((s) => (
                <span
                  key={s.id}
                  className="absolute pointer-events-none"
                  style={{
                    left: `${s.x * 100}%`,
                    top: `${s.y * 100}%`,
                    fontSize: `${s.size * 100}%`,
                    transform: "translate(-50%, -50%)",
                  }}
                >
                  {s.emoji}
                </span>
              ))}
              <span className="absolute top-1.5 left-1.5 bg-white/90 backdrop-blur text-[10px] font-semibold px-1.5 rounded-full">
                #{i + 1}
              </span>
              <span
                role="button"
                tabIndex={0}
                onClick={(e) => {
                  e.stopPropagation();
                  removePanel(p.id);
                }}
                className="absolute top-1.5 right-1.5 bg-white/90 backdrop-blur rounded-full p-1 opacity-0 group-hover:opacity-100 transition"
                aria-label="Remove"
              >
                <Trash2 className="w-3 h-3 text-red-500" />
              </span>
              {p.dialogue && (
                <span className="absolute bottom-1.5 left-1.5 right-1.5 bg-white/90 backdrop-blur text-[10px] font-medium px-1.5 py-0.5 rounded truncate text-slate-800">
                  {p.dialogue}
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function ExportDialog({
  onClose,
  onExport,
}: {
  onClose: () => void;
  onExport: (formatId: string) => void;
}) {
  return (
    <div
      className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 border border-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="text-lg font-semibold mb-1 flex items-center gap-2">
          <Wand2 className="w-5 h-5 text-indigo-500" /> Magic Resize
        </h3>
        <p className="text-sm text-slate-500 mb-5">
          Pick a format. Your comic will be resized and exported as a high-res PNG.
        </p>
        <div className="space-y-1.5 max-h-[60vh] overflow-y-auto">
          {EXPORT_FORMATS.map((f) => (
            <button
              key={f.id}
              onClick={() => onExport(f.id)}
              className="w-full flex items-center justify-between gap-3 p-3 rounded-xl border-2 border-slate-200 hover:border-indigo-500 hover:bg-indigo-50 transition text-left"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className="shrink-0 bg-slate-200 border border-slate-300 rounded"
                  style={{
                    width: 36,
                    height: Math.round(36 * (f.h / f.w)),
                    maxHeight: 60,
                  }}
                />
                <div className="min-w-0">
                  <p className="text-sm font-medium text-slate-900 truncate">
                    {f.label}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    {f.w} × {f.h}px
                  </p>
                </div>
              </div>
              <Download className="w-4 h-4 text-slate-400" />
            </button>
          ))}
        </div>
        <div className="flex justify-end gap-2 mt-5">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-sm text-slate-600 hover:bg-slate-100"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

function BrandKitDialog({
  kit,
  onClose,
  onSave,
}: {
  kit: BrandKit;
  onClose: () => void;
  onSave: (k: BrandKit) => void;
}) {
  const [draft, setDraft] = useState<BrandKit>(kit);
  const [colorDraft, setColorDraft] = useState("#3B82F6");
  const fileRef = useRef<HTMLInputElement>(null);

  const addColor = () => {
    if (!/^#[0-9a-f]{6}$/i.test(colorDraft)) return;
    if (draft.palette.includes(colorDraft)) return;
    setDraft({ ...draft, palette: [...draft.palette, colorDraft] });
  };
  const removeColor = (c: string) =>
    setDraft({ ...draft, palette: draft.palette.filter((x) => x !== c) });

  const addLogo = (file: File) => {
    const r = new FileReader();
    r.onload = () => {
      setDraft({ ...draft, logos: [...draft.logos, r.result as string] });
    };
    r.readAsDataURL(file);
  };

  return (
    <div
      className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-6 border border-slate-200 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Bookmark className="w-5 h-5 text-indigo-500" /> Brand kit
            </h3>
            <p className="text-xs text-slate-500">
              Saved colors, fonts and logos appear in every comic.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-md hover:bg-slate-100 text-slate-500"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mb-5">
          <h4 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
            Brand colors
          </h4>
          <div className="flex gap-2 mb-2">
            <input
              type="color"
              value={colorDraft}
              onChange={(e) => setColorDraft(e.target.value)}
              className="w-12 h-9 rounded border border-slate-300"
            />
            <input
              type="text"
              value={colorDraft}
              onChange={(e) => setColorDraft(e.target.value)}
              className="flex-1 border border-slate-300 rounded-lg px-3 py-1.5 text-sm font-mono"
            />
            <button
              onClick={addColor}
              className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-sm font-medium hover:bg-slate-800"
            >
              Add
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {draft.palette.map((c) => (
              <button
                key={c}
                onClick={() => removeColor(c)}
                className="w-8 h-8 rounded-md border border-slate-300 relative group"
                style={{ background: c }}
                title={`Remove ${c}`}
              >
                <X className="w-3 h-3 absolute top-0.5 right-0.5 text-white opacity-0 group-hover:opacity-100" />
              </button>
            ))}
            {draft.palette.length === 0 && (
              <p className="text-xs text-slate-400">No brand colors yet.</p>
            )}
          </div>
        </div>

        <div className="mb-5">
          <h4 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
            Default font
          </h4>
          <div className="grid grid-cols-5 gap-1.5">
            {FONTS.map((f) => (
              <button
                key={f.id}
                onClick={() =>
                  setDraft({
                    ...draft,
                    fonts: draft.fonts.includes(f.id) ? [] : [f.id],
                  })
                }
                className={`py-2 px-1 text-xs rounded-lg border transition ${
                  draft.fonts.includes(f.id)
                    ? "border-slate-900 bg-slate-50"
                    : "border-slate-200 hover:border-slate-400"
                }`}
                style={{ fontFamily: f.css }}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        <div className="mb-5">
          <h4 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
            Logos
          </h4>
          <div className="flex flex-wrap gap-2 mb-2">
            {draft.logos.map((l, i) => (
              <div key={i} className="relative w-16 h-16 rounded-lg border border-slate-200 bg-slate-50">
                <img src={l} alt="logo" className="w-full h-full object-contain" />
                <button
                  onClick={() =>
                    setDraft({
                      ...draft,
                      logos: draft.logos.filter((_, j) => j !== i),
                    })
                  }
                  className="absolute -top-1.5 -right-1.5 bg-white border border-slate-300 rounded-full p-0.5"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
          <button
            onClick={() => fileRef.current?.click()}
            className="inline-flex items-center gap-1.5 text-sm font-medium px-3 py-1.5 rounded-lg border border-slate-300 hover:bg-slate-100"
          >
            <Upload className="w-3.5 h-3.5" /> Upload logo
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) addLogo(f);
              e.target.value = "";
            }}
          />
        </div>

        <div className="flex justify-end gap-2 mt-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-sm text-slate-600 hover:bg-slate-100"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onSave(draft);
              onClose();
            }}
            className="px-4 py-2 rounded-lg text-sm bg-slate-900 text-white font-medium hover:bg-slate-800"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

function PanelStudio({
  panel,
  brand,
  onChange,
}: {
  panel: Panel;
  brand: BrandKit;
  onChange: (patch: Partial<Panel>) => void;
}) {
  const [color, setColor] = useState<string>(PALETTE[0]);
  const [brush, setBrush] = useState(BRUSHES[1]);
  const [erasing, setErasing] = useState(false);
  const [tab, setTab] = useState<"draw" | "image" | "stickers" | "text">("draw");
  const [aiPrompt, setAiPrompt] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [aiError, setAiError] = useState("");
  const uploadRef = useRef<HTMLInputElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);

  const fontCss = useMemo(
    () => FONTS.find((f) => f.id === (panel.font ?? brand.fonts[0] ?? "system"))?.css ?? FONTS[0].css,
    [panel.font, brand.fonts],
  );
  const textStyle: TextStyleId = panel.textStyle ?? "classic";

  const allPalette = useMemo(
    () => Array.from(new Set([...brand.palette, ...PALETTE])),
    [brand.palette],
  );

  const setSticker = (id: string, patch: Partial<Sticker>) =>
    onChange({
      stickers: (panel.stickers ?? []).map((s) => (s.id === id ? { ...s, ...patch } : s)),
    });
  const addSticker = (emoji: string) =>
    onChange({
      stickers: [
        ...(panel.stickers ?? []),
        { id: uid(), emoji, x: 0.5, y: 0.5, size: 0.18 },
      ],
    });
  const removeSticker = (id: string) =>
    onChange({ stickers: (panel.stickers ?? []).filter((s) => s.id !== id) });

  const onUpload = (file: File) => {
    setAiError("");
    if (!file.type.startsWith("image/")) return;
    const r = new FileReader();
    r.onload = () =>
      onChange({ imageUrl: r.result as string, imageFilter: panel.imageFilter ?? "none" });
    r.readAsDataURL(file);
  };

  const callAI = async (op: "generate" | "edit", prompt: string, image?: string) => {
    setAiBusy(true);
    setAiError("");
    try {
      const r = await fetch("/api/ai-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ op, prompt, image }),
      });
      if (!r.ok) {
        const t = await r.text();
        throw new Error(t || `Error ${r.status}`);
      }
      const data = (await r.json()) as { url: string };
      onChange({ imageUrl: data.url, imageFilter: "none" });
    } catch (e) {
      setAiError(e instanceof Error ? e.message : "AI failed");
    } finally {
      setAiBusy(false);
    }
  };

  const onStickerDrag = (
    e: React.PointerEvent<HTMLSpanElement>,
    id: string,
  ) => {
    if (!stageRef.current) return;
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    const stage = stageRef.current.getBoundingClientRect();
    const move = (ev: PointerEvent) => {
      const nx = Math.max(0.02, Math.min(0.98, (ev.clientX - stage.left) / stage.width));
      const ny = Math.max(0.02, Math.min(0.98, (ev.clientY - stage.top) / stage.height));
      setSticker(id, { x: nx, y: ny });
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  const photoFilterCss =
    PHOTO_FILTERS.find((f) => f.id === (panel.imageFilter ?? "none"))?.css ?? "none";

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-5">
      <div className="rounded-2xl bg-white border border-slate-200 shadow-sm overflow-hidden">
        <div
          ref={stageRef}
          className="relative"
          style={{ background: panel.bg, aspectRatio: "1 / 1" }}
        >
          {panel.imageUrl && (
            <img
              src={panel.imageUrl}
              alt=""
              className="absolute inset-0 w-full h-full object-cover pointer-events-none"
              style={{ filter: photoFilterCss }}
            />
          )}
          <DrawingCanvas
            value={panel.drawing}
            color={color}
            size={brush.size}
            erasing={erasing}
            disabled={tab !== "draw"}
            onChange={(drawing) => onChange({ drawing })}
          />

          {(panel.stickers ?? []).map((s) => (
            <span
              key={s.id}
              onPointerDown={(e) => onStickerDrag(e, s.id)}
              onDoubleClick={() => removeSticker(s.id)}
              className="absolute select-none cursor-move"
              style={{
                left: `${s.x * 100}%`,
                top: `${s.y * 100}%`,
                fontSize: `${s.size * 100}%`,
                transform: "translate(-50%, -50%)",
                touchAction: "none",
              }}
              title="Drag to move, double-click to delete"
            >
              {s.emoji}
            </span>
          ))}

          {panel.dialogue && (
            <div
              className={`pointer-events-none absolute top-4 right-4 max-w-[60%] rounded-2xl px-3 py-1.5 text-sm ${
                TEXT_STYLES.find((t) => t.id === textStyle)?.bubble ?? ""
              } ${TEXT_STYLES.find((t) => t.id === textStyle)?.text ?? ""}`}
              style={{ fontFamily: fontCss }}
            >
              {panel.dialogue}
            </div>
          )}
          {panel.caption && (
            <div
              className={`pointer-events-none absolute bottom-3 left-3 right-3 px-2.5 py-1.5 text-xs ${
                TEXT_STYLES.find((t) => t.id === textStyle)?.bubble ?? ""
              } ${TEXT_STYLES.find((t) => t.id === textStyle)?.text ?? ""}`}
              style={{ fontFamily: fontCss }}
            >
              {panel.caption}
            </div>
          )}
        </div>
      </div>

      <aside className="rounded-2xl bg-white border border-slate-200 shadow-sm p-4 space-y-4">
        <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 rounded-lg text-xs">
          {[
            { id: "draw", label: "Draw", icon: Brush },
            { id: "image", label: "Image", icon: ImageIcon },
            { id: "stickers", label: "Stickers", icon: Smile },
            { id: "text", label: "Text", icon: TypeIcon },
          ].map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id as typeof tab)}
                className={`flex flex-col items-center gap-0.5 py-1.5 rounded-md transition ${
                  tab === t.id ? "bg-white shadow-sm text-slate-900" : "text-slate-500"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {t.label}
              </button>
            );
          })}
        </div>

        {tab === "draw" && (
          <>
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5" /> Palette
                </h4>
                <span
                  className="w-5 h-5 rounded-md border border-slate-300"
                  style={{ background: color }}
                />
              </div>
              {brand.palette.length > 0 && (
                <div className="mb-2">
                  <p className="text-[10px] text-indigo-600 font-medium mb-1">Brand</p>
                  <div className="grid grid-cols-6 gap-1.5">
                    {brand.palette.map((c) => (
                      <button
                        key={c}
                        onClick={() => {
                          setColor(c);
                          setErasing(false);
                        }}
                        className={`aspect-square rounded-lg border-2 ${
                          !erasing && color === c
                            ? "border-indigo-600 scale-110"
                            : "border-slate-200 hover:border-slate-400"
                        }`}
                        style={{ background: c }}
                      />
                    ))}
                  </div>
                </div>
              )}
              <div className="grid grid-cols-6 gap-1.5">
                {PALETTE.map((c) => (
                  <button
                    key={c}
                    onClick={() => {
                      setColor(c);
                      setErasing(false);
                    }}
                    className={`aspect-square rounded-lg border-2 transition ${
                      !erasing && color === c
                        ? "border-slate-900 scale-110 shadow"
                        : "border-slate-200 hover:border-slate-400"
                    }`}
                    style={{ background: c }}
                  />
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Brush className="w-3.5 h-3.5" /> Brushes
              </h4>
              <div className="grid grid-cols-4 gap-1.5">
                {BRUSHES.map((b) => (
                  <button
                    key={b.id}
                    onClick={() => setBrush(b)}
                    className={`flex flex-col items-center justify-center gap-1 py-2 rounded-lg border transition ${
                      brush.id === b.id
                        ? "border-slate-900 bg-slate-50"
                        : "border-slate-200 hover:border-slate-400"
                    }`}
                  >
                    <span
                      className="rounded-full bg-slate-900"
                      style={{ width: b.size, height: b.size }}
                    />
                    <span className="text-[10px] text-slate-600">{b.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => setErasing((e) => !e)}
                className={`flex items-center justify-center gap-1.5 py-2 rounded-lg border text-sm font-medium transition ${
                  erasing
                    ? "bg-slate-900 text-white border-slate-900"
                    : "border-slate-200 hover:border-slate-400 text-slate-700"
                }`}
              >
                <Eraser className="w-4 h-4" /> Eraser
              </button>
              <button
                onClick={() => onChange({ drawing: "" })}
                className="flex items-center justify-center gap-1.5 py-2 rounded-lg border border-slate-200 hover:border-red-300 hover:text-red-600 text-sm font-medium text-slate-700 transition"
              >
                <Undo2 className="w-4 h-4" /> Clear
              </button>
            </div>
          </>
        )}

        {tab === "image" && (
          <div className="space-y-4">
            <div>
              <h4 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
                Photo
              </h4>
              <div className="flex gap-1.5">
                <button
                  onClick={() => uploadRef.current?.click()}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 text-sm font-medium px-3 py-2 rounded-lg border border-slate-300 hover:bg-slate-100"
                >
                  <Upload className="w-3.5 h-3.5" /> Upload
                </button>
                {panel.imageUrl && (
                  <button
                    onClick={() => onChange({ imageUrl: undefined, imageFilter: undefined })}
                    className="inline-flex items-center justify-center gap-1.5 text-sm font-medium px-3 py-2 rounded-lg border border-slate-200 text-red-600 hover:border-red-300"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <input
                ref={uploadRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onUpload(f);
                  e.target.value = "";
                }}
              />
            </div>

            <div>
              <h4 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-500" /> AI image
              </h4>
              <textarea
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                rows={2}
                placeholder="A grumpy cat wearing a tiny crown, comic-book style"
                className="w-full border border-slate-300 rounded-lg px-2.5 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
              <div className="flex gap-1.5 mt-1.5">
                <button
                  disabled={aiBusy || !aiPrompt.trim()}
                  onClick={() => callAI("generate", aiPrompt.trim())}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 text-sm font-medium px-3 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-40"
                >
                  {aiBusy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                  Generate
                </button>
                <button
                  disabled={aiBusy || !panel.imageUrl}
                  onClick={() =>
                    callAI(
                      "edit",
                      "Remove the background completely. Return only the main subject on a fully transparent background. Keep the subject crisp and unchanged.",
                      panel.imageUrl,
                    )
                  }
                  className="inline-flex items-center justify-center gap-1.5 text-sm font-medium px-3 py-2 rounded-lg bg-slate-900 text-white hover:bg-slate-800 disabled:opacity-40"
                  title="Remove background"
                >
                  <Wand2 className="w-3.5 h-3.5" /> BG
                </button>
              </div>
              {aiError && (
                <p className="text-[11px] text-red-600 mt-1.5">{aiError}</p>
              )}
              <p className="text-[10px] text-slate-400 mt-1">
                Powered by Lovable AI. "BG" removes background from current image.
              </p>
            </div>

            {panel.imageUrl && (
              <div>
                <h4 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
                  Filter
                </h4>
                <div className="grid grid-cols-4 gap-1.5">
                  {PHOTO_FILTERS.map((f) => (
                    <button
                      key={f.id}
                      onClick={() => onChange({ imageFilter: f.id })}
                      className={`text-[10px] py-1.5 rounded-md border transition ${
                        (panel.imageFilter ?? "none") === f.id
                          ? "border-slate-900 bg-slate-50"
                          : "border-slate-200 hover:border-slate-400"
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {tab === "stickers" && (
          <div className="space-y-3">
            <h4 className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
              <Smile className="w-3.5 h-3.5" /> Add stickers
            </h4>
            <div className="grid grid-cols-8 gap-1 text-xl">
              {STICKER_EMOJIS.map((e) => (
                <button
                  key={e}
                  onClick={() => addSticker(e)}
                  className="aspect-square rounded-md hover:bg-slate-100 transition"
                >
                  {e}
                </button>
              ))}
            </div>
            {(panel.stickers ?? []).length > 0 && (
              <div>
                <p className="text-[11px] text-slate-500 mb-1.5">
                  On canvas (drag to move • double-click to remove)
                </p>
                <div className="space-y-1.5">
                  {(panel.stickers ?? []).map((s) => (
                    <div key={s.id} className="flex items-center gap-2 text-xs">
                      <span className="text-lg w-6 text-center">{s.emoji}</span>
                      <input
                        type="range"
                        min={0.05}
                        max={0.5}
                        step={0.01}
                        value={s.size}
                        onChange={(e) => setSticker(s.id, { size: Number(e.target.value) })}
                        className="flex-1"
                      />
                      <button
                        onClick={() => removeSticker(s.id)}
                        className="p-1 text-red-500 hover:bg-red-50 rounded"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {tab === "text" && (
          <div className="space-y-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                Dialogue
              </label>
              <input
                value={panel.dialogue}
                onChange={(e) => onChange({ dialogue: e.target.value })}
                placeholder="Hello world!"
                className="w-full border border-slate-300 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                Caption
              </label>
              <input
                value={panel.caption}
                onChange={(e) => onChange({ caption: e.target.value })}
                placeholder="Meanwhile..."
                className="w-full border border-slate-300 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                Style
              </label>
              <div className="grid grid-cols-5 gap-1">
                {TEXT_STYLES.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => onChange({ textStyle: s.id })}
                    className={`text-[10px] py-1.5 rounded-md border transition ${
                      textStyle === s.id
                        ? "border-slate-900 bg-slate-50"
                        : "border-slate-200 hover:border-slate-400"
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                Font
              </label>
              <div className="grid grid-cols-5 gap-1">
                {FONTS.map((f) => (
                  <button
                    key={f.id}
                    onClick={() => onChange({ font: f.id })}
                    style={{ fontFamily: f.css }}
                    className={`text-xs py-2 rounded-md border transition ${
                      (panel.font ?? brand.fonts[0] ?? "system") === f.id
                        ? "border-slate-900 bg-slate-50"
                        : "border-slate-200 hover:border-slate-400"
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                Background
              </label>
              <div className="grid grid-cols-8 gap-1.5">
                {allPalette.slice(0, 16).map((c) => (
                  <button
                    key={c}
                    onClick={() => onChange({ bg: c })}
                    className={`aspect-square rounded-md border-2 ${
                      panel.bg === c
                        ? "border-slate-900"
                        : "border-slate-200 hover:border-slate-400"
                    }`}
                    style={{ background: c }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}
      </aside>
    </div>
  );
}

function DrawingCanvas({
  value,
  color,
  size,
  erasing,
  disabled,
  onChange,
}: {
  value: string;
  color: string;
  size: number;
  erasing: boolean;
  disabled?: boolean;
  onChange: (dataUrl: string) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef(false);
  const lastRef = useRef<{ x: number; y: number } | null>(null);
  const RES = 800;

  // Load existing image into the canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!value) return;
    const img = new Image();
    img.onload = () => ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    img.src = value;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const getPos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const commit = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    onChange(canvas.toDataURL("image/png"));
  }, [onChange]);

  const onDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    drawingRef.current = true;
    lastRef.current = getPos(e);
  };

  const onMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawingRef.current) return;
    const ctx = canvasRef.current!.getContext("2d");
    if (!ctx) return;
    const pos = getPos(e);
    ctx.save();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineWidth = size * (RES / 400);
    if (erasing) {
      ctx.globalCompositeOperation = "destination-out";
      ctx.strokeStyle = "rgba(0,0,0,1)";
    } else {
      ctx.globalCompositeOperation = "source-over";
      ctx.strokeStyle = color;
    }
    ctx.beginPath();
    const last = lastRef.current!;
    ctx.moveTo(last.x, last.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    ctx.restore();
    lastRef.current = pos;
  };

  const onUp = () => {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    lastRef.current = null;
    commit();
  };

  return (
    <canvas
      ref={canvasRef}
      width={RES}
      height={RES}
      className="absolute inset-0 w-full h-full touch-none"
      style={{
        cursor: erasing ? "cell" : "crosshair",
        pointerEvents: disabled ? "none" : "auto",
      }}
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerLeave={onUp}
    />
  );
}

function ShareDialog({ comic, onClose }: { comic: Comic; onClose: () => void }) {
  const [mode, setMode] = useState<"private" | "link">("private");
  const [link, setLink] = useState<string>("");
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string>("");

  const generateLink = () => {
    try {
      const json = JSON.stringify(comic);
      const encoded = btoa(unescape(encodeURIComponent(json)));
      const url = `${window.location.origin}/view#c=${encoded}`;
      if (url.length > 30000) {
        setError(
          "This comic is too large to share via link. Use Export PNG instead.",
        );
        setLink("");
        return;
      }
      setError("");
      setLink(url);
    } catch {
      setError("Could not generate link.");
    }
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* ignore */
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-slate-200 p-5"
      >
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-slate-900">
              Share comic
            </h3>
            <p className="text-xs text-slate-500">Choose how you want to share</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-md hover:bg-slate-100 text-slate-500"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2 mb-4">
          <button
            onClick={() => {
              setMode("private");
              setLink("");
              setError("");
            }}
            className={`w-full text-left flex items-start gap-3 p-3 rounded-xl border-2 transition ${
              mode === "private"
                ? "border-slate-900 bg-slate-50"
                : "border-slate-200 hover:border-slate-300"
            }`}
          >
            <Lock className="w-4 h-4 mt-0.5 text-slate-700" />
            <div>
              <p className="text-sm font-medium text-slate-900">Private</p>
              <p className="text-xs text-slate-500">
                Only saved on your device. Nobody else can see it.
              </p>
            </div>
          </button>
          <button
            onClick={() => {
              setMode("link");
              generateLink();
            }}
            className={`w-full text-left flex items-start gap-3 p-3 rounded-xl border-2 transition ${
              mode === "link"
                ? "border-slate-900 bg-slate-50"
                : "border-slate-200 hover:border-slate-300"
            }`}
          >
            <LinkIcon className="w-4 h-4 mt-0.5 text-slate-700" />
            <div>
              <p className="text-sm font-medium text-slate-900">
                Shareable link
              </p>
              <p className="text-xs text-slate-500">
                Send your friends a link they can open in any browser.
              </p>
            </div>
          </button>
        </div>

        {mode === "link" && (
          <div className="space-y-2">
            {error ? (
              <p className="text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg p-2.5">
                {error}
              </p>
            ) : (
              <>
                <div className="flex items-center gap-2">
                  <input
                    readOnly
                    value={link}
                    className="flex-1 text-xs px-3 py-2 rounded-lg border border-slate-300 bg-slate-50 font-mono truncate"
                    onFocus={(e) => e.currentTarget.select()}
                  />
                  <button
                    onClick={copy}
                    className="inline-flex items-center gap-1.5 text-sm font-medium px-3 py-2 rounded-lg bg-slate-900 text-white hover:bg-slate-800"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5" /> Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" /> Copy
                      </>
                    )}
                  </button>
                </div>
                <p className="text-[11px] text-slate-400">
                  The whole comic is encoded in the link — no account needed to
                  view it.
                </p>
              </>
            )}
          </div>
        )}

        {mode === "private" && (
          <p className="text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-lg p-2.5">
            "{comic.title}" stays in your library on this device.
          </p>
        )}
      </div>
    </div>
  );
}
