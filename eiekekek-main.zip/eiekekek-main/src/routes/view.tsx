import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, BookOpen } from "lucide-react";

export const Route = createFileRoute("/view")({
  component: ViewSharedComic,
});

type Panel = {
  id: string;
  caption: string;
  dialogue: string;
  bg: string;
  drawing: string;
};

type Comic = {
  id: string;
  title: string;
  description: string;
  createdAt: number;
  panels: Panel[];
};

function decodeHash(): Comic | null {
  if (typeof window === "undefined") return null;
  const hash = window.location.hash.replace(/^#/, "");
  const params = new URLSearchParams(hash);
  const raw = params.get("c");
  if (!raw) return null;
  try {
    const json = decodeURIComponent(escape(atob(raw)));
    return JSON.parse(json) as Comic;
  } catch {
    return null;
  }
}

function ViewSharedComic() {
  const [comic, setComic] = useState<Comic | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setComic(decodeHash());
    setReady(true);
  }, []);

  if (!ready) return null;

  if (!comic) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center px-6">
        <div className="text-center max-w-md">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-200 flex items-center justify-center mb-4">
            <BookOpen className="w-6 h-6 text-slate-500" />
          </div>
          <h1 className="text-2xl font-semibold text-slate-900 mb-2">
            No comic to view
          </h1>
          <p className="text-slate-500 mb-6">
            This share link is empty or invalid.
          </p>
          <Link
            to="/"
            className="inline-flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-lg bg-slate-900 text-white hover:bg-slate-800"
          >
            <ArrowLeft className="w-4 h-4" /> Go to Studio
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      <header className="sticky top-0 z-30 backdrop-blur bg-white/80 border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-4 md:px-6 h-14 flex items-center justify-between">
          <Link
            to="/"
            className="flex items-center gap-1.5 text-sm text-slate-600 hover:text-slate-900"
          >
            <ArrowLeft className="w-4 h-4" /> Open Studio
          </Link>
          <span className="text-[11px] uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full font-medium">
            Shared comic
          </span>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 md:px-6 py-10">
        <h1 className="text-3xl md:text-5xl font-semibold tracking-tight">
          {comic.title}
        </h1>
        {comic.description && (
          <p className="mt-3 text-slate-500 max-w-2xl">{comic.description}</p>
        )}

        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {comic.panels.map((p, i) => (
            <figure
              key={p.id}
              className="relative aspect-square rounded-2xl overflow-hidden border border-slate-200 shadow-sm"
              style={{ background: p.bg }}
            >
              {p.drawing && (
                <img
                  src={p.drawing}
                  alt={`Panel ${i + 1}`}
                  className="absolute inset-0 w-full h-full object-cover"
                />
              )}
              {p.dialogue && (
                <div className="absolute top-3 right-3 max-w-[55%] bg-white border-2 border-slate-900 rounded-2xl px-3 py-1.5 text-sm font-medium shadow">
                  {p.dialogue}
                </div>
              )}
              {p.caption && (
                <div className="absolute bottom-3 left-3 right-3 bg-yellow-100 border border-slate-900 px-2.5 py-1.5 text-xs font-medium">
                  {p.caption}
                </div>
              )}
              <span className="absolute top-2 left-2 bg-white/90 backdrop-blur text-[10px] font-semibold px-1.5 rounded-full">
                #{i + 1}
              </span>
            </figure>
          ))}
        </div>

        {comic.panels.length === 0 && (
          <p className="mt-10 text-center text-slate-400">
            This comic has no panels yet.
          </p>
        )}
      </main>
    </div>
  );
}
